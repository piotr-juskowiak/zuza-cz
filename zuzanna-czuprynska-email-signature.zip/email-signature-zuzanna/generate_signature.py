#!/usr/bin/env python3
import os
import math
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

# Set up paths relative to this script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(SCRIPT_DIR, "assets")
FONTS_DIR = os.path.join(ASSETS_DIR, "fonts")
ICONS_DIR = os.path.join(ASSETS_DIR, "icons")
UPLOAD_DIR = os.path.join(SCRIPT_DIR, "upload", "email-signature")

# Ensure upload directory exists
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Design Constants
BG_COLOR = (249, 248, 246)  # #F9F8F6 (warm paper background)
BG_HEX = "#F9F8F6"
COLOR_PRIMARY = (26, 46, 40)  # #1A2E28 (deep forest green)
COLOR_SECONDARY = (92, 107, 102)  # #5C6B66 (sage-ish dark green/grey)
COLOR_LIGHT = (115, 130, 125)  # #73827D (darker sage/gray for better contrast and elegance)
COLOR_GOLD = (197, 160, 101)  # #C5A065 (brand gold)

# Animation Settings
TOTAL_FRAMES = 50
FRAME_DELAY = 30  # 30 ms per frame (approx 33 fps)

# Load fonts
FONT_NAME_REG = os.path.join(FONTS_DIR, "CormorantGaramond.ttf")
FONT_NAME_ITALIC = os.path.join(FONTS_DIR, "CormorantGaramond-Italic.ttf")
FONT_SANS = os.path.join(FONTS_DIR, "PlusJakartaSans-Medium.ttf")

# Helper: Draw tracked text
def draw_text_tracked(draw, text, x, y, font, fill, tracking):
    cursor_x = x
    for char in text:
        draw.text((cursor_x, y), char, font=font, fill=fill)
        cursor_x += font.getlength(char) + tracking
    return cursor_x

# Helper: Easing function (ease-out-cubic)
def ease_out_cubic(t):
    return 1.0 - math.pow(1.0 - t, 3.0)

# Main GIF Generation Class
class SignatureAssetGenerator:
    def __init__(self):
        # Load fonts at 3x scale
        self.font_slogan = ImageFont.truetype(FONT_SANS, int(8 * 3))
        self.font_name_reg = ImageFont.truetype(FONT_NAME_REG, int(25 * 3))
        self.font_name_italic = ImageFont.truetype(FONT_NAME_ITALIC, int(25 * 3))
        self.font_role = ImageFont.truetype(FONT_NAME_ITALIC, int(13.5 * 3))
        self.font_links = ImageFont.truetype(FONT_SANS, int(10.5 * 3))
        self.font_quote = ImageFont.truetype(FONT_NAME_ITALIC, int(11.5 * 3))

    def create_element_frames_v2(self, name, width, height, start_frame, end_frame, draw_callback, slide_dist=12):
        w3x, h3x = width * 3, height * 3
        slide_dist_3x = slide_dist * 3
        frames = []

        # Frame 0: Complete final state
        frame_0_3x = Image.new("RGBA", (w3x, h3x), BG_COLOR + (255,))
        draw_0 = ImageDraw.Draw(frame_0_3x)
        draw_callback(frame_0_3x, draw_0, w3x, h3x)
        
        # Convert to RGB by alpha blending with BG_COLOR
        frame_0_rgb = Image.new("RGB", (w3x, h3x), BG_COLOR)
        frame_0_rgb.paste(frame_0_3x, (0, 0), mask=frame_0_3x.split()[3])
        frame_0 = frame_0_rgb.resize((width, height), Image.Resampling.LANCZOS)
        frames.append(frame_0)

        # Frame 1: Hidden state
        frame_1 = Image.new("RGB", (width, height), BG_COLOR)
        frames.append(frame_1)

        # Frames 2 to 49
        for frame_idx in range(2, TOTAL_FRAMES):
            anim_frame = frame_idx - 2
            
            if anim_frame < start_frame:
                frames.append(frame_1)
            elif anim_frame >= end_frame:
                frames.append(frame_0)
            else:
                t = (anim_frame - start_frame) / (end_frame - start_frame)
                ease_t = ease_out_cubic(t)
                
                # Render content layer with transparent bg
                content_layer = Image.new("RGBA", (w3x, h3x), (0, 0, 0, 0))
                draw_content = ImageDraw.Draw(content_layer)
                draw_callback(content_layer, draw_content, w3x, h3x)
                
                # Apply opacity and vertical offset
                offset_y = int(slide_dist_3x * (1.0 - ease_t))
                
                # Create final 3x canvas
                canvas_3x = Image.new("RGB", (w3x, h3x), BG_COLOR)
                
                # Fade alpha channel
                r, g, b, a = content_layer.split()
                a_faded = a.point(lambda p: int(p * ease_t))
                content_faded = Image.merge("RGBA", (r, g, b, a_faded))
                
                canvas_3x.paste(content_faded, (0, -offset_y), mask=content_faded)
                
                # Downsample
                frame = canvas_3x.resize((width, height), Image.Resampling.LANCZOS)
                frames.append(frame)

        # Quantize all frames to P mode using frame_0's palette for size optimization
        frame_0_p = frames[0].convert("P", palette=Image.Palette.ADAPTIVE, colors=128)
        frames_p = [frame_0_p]
        for f in frames[1:]:
            frames_p.append(f.quantize(palette=frame_0_p))

        # Save
        gif_path = os.path.join(UPLOAD_DIR, f"{name}.gif")
        frames_p[0].save(
            gif_path,
            save_all=True,
            append_images=frames_p[1:],
            duration=FRAME_DELAY,
            loop=1,
            optimize=True,
            disposal=2
        )
        
        png_path = os.path.join(UPLOAD_DIR, f"{name}.png")
        frames[0].save(png_path)
        print(f"Generated {name}.gif and {name}.png")
        return frames

    def generate_all_v2(self):
        # 1. Slogan (KOBIETA · AKTYWISTKA · LIDERKA)
        def draw_slogan(img, draw, w, h):
            text = "KOBIETA  ·  AKTYWISTKA  ·  LIDERKA"
            draw_text_tracked(draw, text, 0, 8, self.font_slogan, COLOR_GOLD, 8)
        slogan_frames = self.create_element_frames_v2("slogan", 320, 16, 2, 12, draw_slogan, slide_dist=8)

        # 2. Name
        def draw_name(img, draw, w, h):
            text_first = "Zuzanna Maria "
            text_last = "Czupryńska"
            draw.text((0, 0), text_first, font=self.font_name_reg, fill=COLOR_PRIMARY)
            w_first = self.font_name_reg.getlength(text_first)
            draw.text((w_first, 0), text_last, font=self.font_name_italic, fill=COLOR_PRIMARY)
        name_frames = self.create_element_frames_v2("name", 320, 32, 5, 17, draw_name, slide_dist=10)

        # 3. Role
        def draw_role(img, draw, w, h):
            text = "Fundatorka i Prezes Beehouses Foundation"
            draw.text((0, 4), text, font=self.font_role, fill=COLOR_SECONDARY)
        role_frames = self.create_element_frames_v2("role", 320, 20, 9, 21, draw_role, slide_dist=8)

        # 4. Divider (growing line from left to right)
        divider_frames = self.create_divider_frames()

        # 5. Email link (icon + text)
        mail_icon_path = os.path.join(ICONS_DIR, "mail.png")
        mail_icon = Image.open(mail_icon_path).convert("RGBA")
        
        def draw_email(img, draw, w, h):
            icon_3x = mail_icon.resize((42, 42), Image.Resampling.LANCZOS)
            img.paste(icon_3x, (0, 3), mask=icon_3x)
            draw.text((54, 4), "kontakt@zuzanna-czuprynska.pl", font=self.font_links, fill=COLOR_PRIMARY)
        email_frames = self.create_element_frames_v2("email", 220, 16, 13, 27, draw_email, slide_dist=8)

        # 6. Globe link (icon + text)
        globe_icon_path = os.path.join(ICONS_DIR, "globe.png")
        globe_icon = Image.open(globe_icon_path).convert("RGBA")
        
        def draw_globe(img, draw, w, h):
            icon_3x = globe_icon.resize((42, 42), Image.Resampling.LANCZOS)
            img.paste(icon_3x, (0, 3), mask=icon_3x)
            draw.text((54, 4), "zuzanna-czuprynska.pl", font=self.font_links, fill=COLOR_PRIMARY)
        globe_frames = self.create_element_frames_v2("globe", 180, 16, 15, 29, draw_globe, slide_dist=8)

        # 7. Instagram
        insta_icon_path = os.path.join(ICONS_DIR, "instagram.png")
        insta_icon = Image.open(insta_icon_path).convert("RGBA")
        def draw_instagram(img, draw, w, h):
            icon_3x = insta_icon.resize((54, 54), Image.Resampling.LANCZOS)
            img.paste(icon_3x, (0, 0), mask=icon_3x)
        instagram_frames = self.create_element_frames_v2("instagram", 18, 18, 17, 29, draw_instagram, slide_dist=8)

        # 8. Facebook
        fb_icon_path = os.path.join(ICONS_DIR, "facebook.png")
        fb_icon = Image.open(fb_icon_path).convert("RGBA")
        def draw_facebook(img, draw, w, h):
            icon_3x = fb_icon.resize((54, 54), Image.Resampling.LANCZOS)
            img.paste(icon_3x, (0, 0), mask=icon_3x)
        facebook_frames = self.create_element_frames_v2("facebook", 18, 18, 19, 31, draw_facebook, slide_dist=8)

        # 9. LinkedIn
        li_icon_path = os.path.join(ICONS_DIR, "linkedin.png")
        li_icon = Image.open(li_icon_path).convert("RGBA")
        def draw_linkedin(img, draw, w, h):
            icon_3x = li_icon.resize((54, 54), Image.Resampling.LANCZOS)
            img.paste(icon_3x, (0, 0), mask=icon_3x)
        linkedin_frames = self.create_element_frames_v2("linkedin", 18, 18, 21, 33, draw_linkedin, slide_dist=8)

        # 10. Quote
        def draw_quote(img, draw, w, h):
            text = "Przyszłość buduje się od natury."
            text_w = self.font_quote.getlength(text)
            draw.text((w - text_w, 4), text, font=self.font_quote, fill=COLOR_LIGHT)
        quote_frames = self.create_element_frames_v2("quote", 200, 16, 23, 37, draw_quote, slide_dist=8)

        # 11. Portrait (Arch Frame)
        portrait_path = os.path.join(ASSETS_DIR, "portrait_orig.jpg")
        orig_portrait = Image.open(portrait_path).convert("RGB")
        
        # Crop her face (width=900, height=1177, aspect ratio 130:170)
        px, py = 153, 50
        pw, ph = 900, 1177
        cropped_portrait = orig_portrait.crop((px, py, px + pw, py + ph))
        
        portrait_3x = cropped_portrait.resize((390, 510), Image.Resampling.LANCZOS)
        
        # Apply gentle sepia filter and contrast enhancement
        sepia_color = Image.new("RGB", (390, 510), (220, 200, 170))
        portrait_3x = Image.blend(portrait_3x, sepia_color, 0.08)  # ~8% sepia
        enhancer = ImageEnhance.Contrast(portrait_3x)
        portrait_3x = enhancer.enhance(1.05)  # 1.05 contrast
        
        # Build Arch Mask at 3x
        arch_mask = Image.new("L", (390, 510), 0)
        draw_mask = ImageDraw.Draw(arch_mask)
        draw_mask.ellipse((0, 0, 390, 390), fill=255)
        draw_mask.rectangle((0, 195, 390, 510), fill=255)

        def draw_portrait(img, draw, w, h):
            portrait_layer = Image.new("RGBA", (390, 510), (0, 0, 0, 0))
            portrait_layer.paste(portrait_3x, (0, 0), mask=arch_mask)
            img.paste(portrait_layer, (0, 0), mask=portrait_layer)
            
        portrait_frames = self.create_element_frames_v2("portrait", 130, 170, 6, 38, draw_portrait, slide_dist=12)

        # 12. Combined Demo GIF & Static Full Preview
        self.generate_combined_assets(
            slogan_frames, name_frames, role_frames, divider_frames,
            email_frames, globe_frames, instagram_frames, facebook_frames,
            linkedin_frames, quote_frames, portrait_frames
        )

    def create_divider_frames(self):
        width, height = 320, 2
        w3x, h3x = width * 3, height * 3
        frames = []
        
        def draw_grad_divider(canvas, w, h, current_w=None):
            if current_w is None:
                current_w = w
            
            line_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw_line = ImageDraw.Draw(line_layer)
            
            fade_len = 180  # 60px * 3 = 180px
            for x in range(current_w):
                if x < fade_len:
                    alpha = int(255 * (x / fade_len))
                elif x > w - fade_len:
                    alpha = int(255 * ((w - x) / fade_len))
                else:
                    alpha = 255
                
                # Draw vertical slice
                draw_line.line([(x, 2), (x, 3)], fill=COLOR_GOLD + (alpha,))
                
            canvas.paste(line_layer, (0, 0), mask=line_layer)
        
        # Frame 0: Final state
        frame_0_3x = Image.new("RGBA", (w3x, h3x), BG_COLOR + (255,))
        draw_grad_divider(frame_0_3x, w3x, h3x)
        frame_0_rgb = Image.new("RGB", (w3x, h3x), BG_COLOR)
        frame_0_rgb.paste(frame_0_3x, (0, 0), mask=frame_0_3x.split()[3])
        frame_0 = frame_0_rgb.resize((width, height), Image.Resampling.LANCZOS)
        frames.append(frame_0)
        
        # Frame 1: Blank
        frame_1 = Image.new("RGB", (width, height), BG_COLOR)
        frames.append(frame_1)
        
        start_frame = 10
        end_frame = 23
        
        for frame_idx in range(2, TOTAL_FRAMES):
            anim_frame = frame_idx - 2
            
            if anim_frame < start_frame:
                frames.append(frame_1)
            elif anim_frame >= end_frame:
                frames.append(frame_0)
            else:
                t = (anim_frame - start_frame) / (end_frame - start_frame)
                ease_t = ease_out_cubic(t)
                
                canvas_3x = Image.new("RGBA", (w3x, h3x), BG_COLOR + (255,))
                current_w = int(w3x * ease_t)
                draw_grad_divider(canvas_3x, w3x, h3x, current_w)
                
                canvas_rgb = Image.new("RGB", (w3x, h3x), BG_COLOR)
                canvas_rgb.paste(canvas_3x, (0, 0), mask=canvas_3x.split()[3])
                
                frame = canvas_rgb.resize((width, height), Image.Resampling.LANCZOS)
                frames.append(frame)
                
        # Quantize frames to P mode for divider.gif
        frame_0_p = frames[0].convert("P", palette=Image.Palette.ADAPTIVE, colors=64)
        frames_p = [frame_0_p]
        for f in frames[1:]:
            frames_p.append(f.quantize(palette=frame_0_p))
            
        # Save
        frames_p[0].save(
            os.path.join(UPLOAD_DIR, "divider.gif"),
            save_all=True,
            append_images=frames_p[1:],
            duration=FRAME_DELAY,
            loop=1,
            optimize=True,
            disposal=2
        )
        frames[0].save(os.path.join(UPLOAD_DIR, "divider.png"))
        print("Generated divider.gif and divider.png")
        return frames

    def generate_combined_assets(self, slogan_f, name_f, role_f, div_f, email_f, globe_f, insta_f, fb_f, li_f, quote_f, portrait_f):
        card_w, card_h = 620, 210
        combined_frames = []

        # Coordinates layout (1x scale)
        px, py = 24, 20     # Portrait
        tx = 180            # Right text column start
        
        slogan_y = 22
        name_y = 38
        role_y = 70
        div_y = 98
        
        email_y = 118
        globe_y = 118
        globe_x = 400       
        
        social_y = 168
        quote_y = 168
        quote_x = 400       

        # Compile 50 frames
        for frame_idx in range(TOTAL_FRAMES):
            card = Image.new("RGB", (card_w, card_h), BG_COLOR)
            
            card.paste(portrait_f[frame_idx], (px, py))
            card.paste(slogan_f[frame_idx], (tx, slogan_y))
            card.paste(name_f[frame_idx], (tx, name_y))
            card.paste(role_f[frame_idx], (tx, role_y))
            card.paste(div_f[frame_idx], (tx, div_y))
            card.paste(email_f[frame_idx], (tx, email_y))
            card.paste(globe_f[frame_idx], (globe_x, globe_y))
            card.paste(insta_f[frame_idx], (tx, social_y))
            card.paste(fb_f[frame_idx], (tx + 32, social_y))
            card.paste(li_f[frame_idx], (tx + 64, social_y))
            card.paste(quote_f[frame_idx], (quote_x, quote_y))

            combined_frames.append(card)

        # Save Demo GIF (infinite loop, loop=0)
        demo_path = os.path.join(SCRIPT_DIR, "zuzanna-signature-demo.gif")
        
        # Quantize demo frames to P mode using first frame's palette (256 colors for demo to preserve highest quality)
        demo_f0_p = combined_frames[0].convert("P", palette=Image.Palette.ADAPTIVE, colors=256)
        demo_frames_p = [demo_f0_p]
        for f in combined_frames[1:]:
            demo_frames_p.append(f.quantize(palette=demo_f0_p))

        demo_frames_p[0].save(
            demo_path,
            save_all=True,
            append_images=demo_frames_p[1:],
            duration=FRAME_DELAY,
            loop=0,
            optimize=True,
            disposal=2
        )
        print(f"Saved demo signature to {demo_path}")

        # Save Static Signature Preview PNG
        static_preview_path = os.path.join(SCRIPT_DIR, "zuzanna-signature-static.png")
        combined_frames[0].save(static_preview_path)
        print(f"Saved static signature preview to {static_preview_path}")

        # Generate Animation Contact Sheet
        indices = [1, 7, 14, 21, 27, 34, 41, 0]
        labels = ["0.0s", "0.2s", "0.4s", "0.6s", "0.8s", "1.0s", "1.2s", "Final"]
        
        col_count = 4
        row_count = 2
        
        spacing_x, spacing_y = 15, 30
        frame_w, frame_h = card_w, card_h
        
        label_height = 20
        grid_w = col_count * frame_w + (col_count + 1) * spacing_x
        grid_h = row_count * (frame_h + label_height) + (row_count + 1) * spacing_y

        sheet = Image.new("RGB", (grid_w, grid_h), (255, 255, 255))
        draw_sheet = ImageDraw.Draw(sheet)
        font_label = ImageFont.truetype(FONT_SANS, 14)

        for i, idx in enumerate(indices):
            col = i % col_count
            row = i // col_count
            
            x = spacing_x + col * (frame_w + spacing_x)
            y = spacing_y + row * (frame_h + label_height + spacing_y)
            
            label = labels[i]
            draw_sheet.text((x, y), label, font=font_label, fill=(26, 46, 40))
            
            frame_img = combined_frames[idx].copy()
            frame_draw = ImageDraw.Draw(frame_img)
            frame_draw.rectangle((0, 0, frame_w - 1, frame_h - 1), outline=(229, 223, 213))
            
            sheet.paste(frame_img, (x, y + label_height))

        sheet_path = os.path.join(SCRIPT_DIR, "animation-contact-sheet.png")
        sheet.save(sheet_path)
        print(f"Saved contact sheet to {sheet_path}")


if __name__ == "__main__":
    print("Starting email signature asset generation...")
    generator = SignatureAssetGenerator()
    generator.generate_all_v2()
    print("Asset generation complete!")
